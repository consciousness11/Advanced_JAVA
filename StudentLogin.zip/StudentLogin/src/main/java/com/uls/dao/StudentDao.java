package com.uls.dao;

import com.uls.model.Student;
import com.uls.utils.DbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class StudentDao {
    
    public void insertStudent(Student student) {
        try { 
            Connection con = DbConnection.getConnection();
            String qry = "insert into student(studentName, studentAddress ) values(?,?)";
            PreparedStatement pst = con.prepareStatement(qry);
            pst.setString(1, student.getStudentName());
            pst.setString(2, student.getStudentAddress());
            
            pst.execute();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public List<Student> getStudentList() {
        try {
            
            List<Student> studentList = new ArrayList<Student>();
            
            Connection con = DbConnection.getConnection();
            String qry = "select * from student";
            
            PreparedStatement pst = con.prepareStatement(qry);
            
            ResultSet rs = pst.executeQuery();
            
            while (rs.next()) {
                Student student = new Student();
                student.setStudentID(rs.getInt("studentId"));
                student.setStudentName(rs.getString("studentName"));
                student.setStudentAddress(rs.getString("studentAddress"));
                
                studentList.add(student);
            }
            
            return studentList;
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    
    public Student getStudent(int studentId) {
        try {
  
            Connection con = DbConnection.getConnection();
            String qry = "select * from student where studentId = ?";
            
            PreparedStatement pst = con.prepareStatement(qry);
            pst.setInt(1, studentId);
            ResultSet rs = pst.executeQuery();
            
            while (rs.next()) {
                Student student = new Student();
                student.setStudentID(rs.getInt("studentId"));
                student.setStudentName(rs.getString("studentName"));
                student.setStudentAddress(rs.getString("studentAddress"));
                
                return student;
            }
            

            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    
    
    public void deleteStudent(int studentId) {
        
        try {
            Connection con = DbConnection.getConnection();
            String qry = "delete from student where studentId = ?";
            PreparedStatement pst = con.prepareStatement(qry);
            pst.setInt(1, studentId);
            
            pst.execute();
            con.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void updateStudent(Student student){
        try{
            
            Connection con = DbConnection.getConnection();
            String qry = "update student set studentName = ? , studentAddress = ? where studentId = ?";
            PreparedStatement pst = con.prepareStatement(qry);
            pst.setString(1, student.getStudentName());
            pst.setString(2, student.getStudentAddress());
            pst.setInt(3, student.getStudentID());
            
            pst.executeUpdate();
            
            con.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
}
