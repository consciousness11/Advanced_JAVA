package com.uls.login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uls.auth.Validation;

public class Login extends HttpServlet{

	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException,IOException{
		response.setContentType("text/html");
		String userName = request.getParameter("user_name");
		String password = request.getParameter("password");
		PrintWriter ps = response.getWriter();
		ps.println("UN  "+userName);
		ps.println("PW  "+password);
		Validation v = new Validation();
		boolean result= v.verifyUser(userName.trim(),password.trim());
		ps.println("RESULT  "+result);
		if(result==true)
		{
			ps.println("<html><body>");
			ps.println("Welcome  "+userName);
			ps.println("</body></html>");
		}
		else 
		{
			ps.println("<html><body>");
			ps.println("Access Denied !  ");
			ps.println("</body></html>");
		}
		
		ps.close();
	}

}
