package com.uls.auth;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Validation {
	public  boolean verifyUser(String username,String password)
	{	boolean state = false;
				
		try 
		{
		Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager
			.getConnection("jdbc:mysql://localhost:3306/login","root","");
			PreparedStatement ps = 
			con.prepareStatement("select * from info where username=? and password=?");
			ps.setString(1,username);
			ps.setString(2,password);
			ResultSet rs = ps.executeQuery();
			state=rs.next();
			
			
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}	
		
			
		return state;
	}

}
